import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('About'),
        backgroundColor: Colors.greenAccent,
      ),
      body: Stack(
        children: [
          // Background Image
          Positioned.fill(
            child: Image.asset(
              'assets/images/background.jpg', // Ensure this image is in your assets folder
              fit: BoxFit.cover,
            ),
          ),
          // Semi-transparent overlay
          Positioned.fill(
            child: Container(
              color: Colors.black.withOpacity(0.6),
            ),
          ),
          // Content
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'About the App',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.greenAccent,
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  'This app predicts diseases based on symptoms provided by the user and offers medical recommendations. It aims to provide valuable insights and assistance to users seeking to understand their health conditions better.',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.justify,
                ),
                SizedBox(height: 30),
                Text(
                  'Meet the Team:',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.greenAccent,
                  ),
                ),
                SizedBox(height: 20),
                Expanded(
                  child: ListView(
                    children: [
                      _buildTeamMember(
                        name: 'Ebenezer Damptey',
                        role: 'Lead Developer',
                        imagePath: 'assets/images/Ebenezer.jpg',
                      ),
                      _buildTeamMember(
                        name: 'Derrick Donkor',
                        role: 'UI/UX Designer',
                        imagePath: 'assets/images/Derrick.jpg',
                      ),
                      _buildTeamMember(
                        name: 'Felix Dongbetigr',
                        role: 'Data Scientist',
                        imagePath: 'assets/images/Felix.jpg',
                      ),
                      _buildTeamMember(
                        name: 'Amponsah Lucas',
                        role: 'UI/UX Designer',
                        imagePath: 'assets/images/Amponsah.jpg',
                      ),
                      _buildTeamMember(
                        name: 'Sundong Wisdom Natonaah',
                        role: 'UI/UX Designer',
                        imagePath: 'assets/images/Sundong.jpg',
                      ),
                      _buildTeamMember(
                        name: 'Asare Nana Kwasi',
                        role: 'UI/UX Designer',
                        imagePath: 'assets/images/team_6.jpg',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTeamMember({
    required String name,
    required String role,
    required String imagePath,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          CircleAvatar(
            radius: 30,
            backgroundImage: AssetImage(imagePath),
          ),
          SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.greenAccent,
                  ),
                ),
                Text(
                  role,
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
