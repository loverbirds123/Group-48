import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Responsive Background Image
          Positioned.fill(
            child: Image.asset(
              'assets/images/background.jpg',
              fit: BoxFit.cover,
            ),
          ),
          // Gradient overlay for a more dynamic look
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.black.withOpacity(0.8),
                    Colors.black.withOpacity(0.6),
                    Colors.black.withOpacity(0.4),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
          // Content
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // App Title with Adaptive Text Size
                  Text(
                    'Disease Predictor',
                    style: TextStyle(
                      fontSize: MediaQuery.of(context).size.width * 0.1,
                      fontWeight: FontWeight.bold,
                      color: Colors.greenAccent,
                      shadows: [
                        Shadow(
                          blurRadius: 10.0,
                          color: Colors.black45,
                          offset: Offset(2, 2),
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 10),
                  // App Description with Adaptive Text Size
                  Text(
                    'Predict diseases based on symptoms input and get medical recommendations.',
                    style: TextStyle(
                      fontSize: MediaQuery.of(context).size.width * 0.045,
                      color: Colors.white,
                      shadows: [
                        Shadow(
                          blurRadius: 8.0,
                          color: Colors.black45,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 40),
                  // Buttons with Modern Styling
                  _buildElevatedButton(
                    context,
                    label: 'Predict Disease',
                    icon: Icons.health_and_safety,
                    color: Colors.blueAccent,
                    routeName: '/predict',
                  ),
                  SizedBox(height: 20),
                  _buildElevatedButton(
                    context,
                    label: 'About',
                    icon: Icons.info,
                    color: Colors.greenAccent,
                    routeName: '/about',
                  ),
                  SizedBox(height: 20),
                  _buildElevatedButton(
                    context,
                    label: 'Contact',
                    icon: Icons.contact_page,
                    color: Colors.orangeAccent,
                    routeName: '/contact',
                  ),
                  SizedBox(height: 20),
                  // Logout Button
                  _buildElevatedButton(
                    context,
                    label: 'Logout',
                    icon: Icons.logout,
                    color: Colors.redAccent,
                    routeName: '/login', // Assuming your login page is defined with this route
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Improved button builder with animation
  Widget _buildElevatedButton(BuildContext context, {
    required String label,
    required IconData icon,
    required Color color,
    required String routeName,
  }) {
    return GestureDetector(
      onTapDown: (_) {
        // Optional: add haptic feedback on button press
        // HapticFeedback.lightImpact();
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        transform: Matrix4.identity()..scale(1.05),
        child: ElevatedButton.icon(
          icon: Icon(icon),
          label: Text(label),
          style: ElevatedButton.styleFrom(
            backgroundColor: color,
            padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
            textStyle: TextStyle(fontSize: 20),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
            elevation: 10,
            shadowColor: Colors.black45,
          ),
          onPressed: () {
            Navigator.pushNamed(context, routeName);
          },
        ),
      ),
    );
  }
}
