from flask import Flask, request, jsonify
import numpy as np
import pandas as pd
import pickle
from flask_cors import CORS
from sklearn.preprocessing import LabelEncoder

app = Flask(__name__)
CORS(app)

# Load datasets
description = pd.read_csv("dataset/description.csv")
precautions = pd.read_csv("dataset/precautions_df.csv")
workout = pd.read_csv("dataset/workout_df.csv")
medications = pd.read_csv('dataset/medications.csv')
diets = pd.read_csv("dataset/diets.csv")

# Load the trained model
model = pickle.load(open('model/best_model.pkl', 'rb'))

# Initialize and fit the LabelEncoder
le = LabelEncoder()
le.fit(['Malaria', 'Hepatitis B'])

# Define the relevant symptoms for the diseases
relevant_symptoms = [
    'fatigue', 'yellowish_skin', 'dark_urine', 'loss_of_appetite', 
    'abdominal_pain', 'nausea', 'joint_pain', 'malaise', 'yellow_urine', 
    'yellowing_of_eyes', 'acute_liver_failure', 'swelling_of_stomach', 
    'fluid_overload', 'shivering', 'chills', 'high_fever', 'sweating', 
    'headache', 'vomiting', 'muscle_pain', 'diarrhoea', 'mild_fever'
]

# Helper function to get all relevant disease information
def get_disease_info(disease):
    # Get description
    description_text = description[description['Disease'] == disease]['Description'].values[0]

    # Get precautions
    precautions_list = precautions[precautions['Disease'] == disease].values[0][1:].tolist()

    # Get workout recommendations
    workout_list = workout[workout['disease'] == disease]['workout'].tolist()

    # Get medications
    medications_list = medications[medications['Disease'] == disease]['Medication'].tolist()

    # Get diets
    diet_list = diets[diets['Disease'] == disease]['Diet'].tolist()
    
    return {
        'description': description_text,
        'precautions': precautions_list,
        'workouts': workout_list,
        'medications': medications_list,
        'diets': diet_list
    }

# Function to predict disease based on symptoms
def get_predicted_value(patient_symptoms):
    # Initialize input vector
    input_vector = np.zeros(len(relevant_symptoms))
    symptom_dict = {symptom: idx for idx, symptom in enumerate(relevant_symptoms)}
    
    # Map symptoms to the input vector
    for symptom in patient_symptoms:
        if symptom in symptom_dict:
            input_vector[symptom_dict[symptom]] = 1

    # If no valid symptoms provided, return None
    if np.sum(input_vector) == 0:
        return None

    # Predict the disease using the trained model
    predicted_index = model.predict([input_vector])[0]
    predicted_disease = le.inverse_transform([predicted_index])[0]
    
    return predicted_disease

# Endpoint for disease prediction
@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    symptoms = data.get('symptoms')
    
    # Error handling for missing symptoms
    if not symptoms:
        return jsonify({'error': 'No symptoms provided'}), 400
    
    # Process and predict based on symptoms
    user_symptoms = [s.strip() for s in symptoms.split(',')]
    predicted_disease = get_predicted_value(user_symptoms)
    
    if predicted_disease is None:
        return jsonify({'error': 'No valid symptoms provided.'}), 400
    
    # Retrieve detailed information for the predicted disease
    disease_info = get_disease_info(predicted_disease)
    
    # Create the response structure
    response = {
        'predicted_disease': predicted_disease,
        'description': disease_info['description'],
        'precautions': disease_info['precautions'],
        'workouts': disease_info['workouts'],
        'medications': disease_info['medications'],
        'diets': disease_info['diets']
    }
    
    return jsonify(response)

# Run the Flask application
if __name__ == '__main__':
    app.run(debug=True, port=5050)
