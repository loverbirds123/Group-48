import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class PredictionPage extends StatefulWidget {
  @override
  _PredictionPageState createState() => _PredictionPageState();
}

class _PredictionPageState extends State<PredictionPage> {
  final TextEditingController _symptomsController = TextEditingController();
  Map<String, dynamic>? _predictionResult;
  String? _errorMessage;

  Future<void> _predictDisease() async {
    final symptoms = _symptomsController.text.trim();
    if (symptoms.isEmpty) {
      setState(() {
        _errorMessage = 'Please enter symptoms.';
        _predictionResult = null;
      });
      return;
    }

    try {
      final response = await http.post(
        Uri.parse('https://41d5-102-176-94-211.ngrok-free.app/predict'), // Use the correct endpoint
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{'symptoms': symptoms}),
      );

      if (response.statusCode == 200) {
        setState(() {
          _predictionResult = jsonDecode(response.body);
          _errorMessage = null;
        });
      } else {
        setState(() {
          _errorMessage = 'Could not predict the disease.';
          _predictionResult = null;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error occurred: $e';
        _predictionResult = null;
      });
    }
  }

  Widget _buildPredictionResults() {
    if (_predictionResult == null) {
      if (_errorMessage != null) {
        return Center(
          child: Text(
            _errorMessage!,
            style: TextStyle(color: Colors.red, fontSize: 18),
          ),
        );
      }
      return SizedBox.shrink();
    }

    final data = _predictionResult!;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Divider(height: 40, thickness: 2, color: Colors.white),
        _buildResultSection('Predicted Disease:', data['predicted_disease'] ?? 'N/A', Colors.greenAccent),
        _buildResultSection('Description:', data['description'] ?? 'N/A', Colors.white70),
        _buildListSection('Precautions:', List<String>.from(data['precautions'] ?? [])),
        _buildListSection('Workouts:', List<String>.from(data['workouts'] ?? [])),
        _buildListSection('Medications:', List<String>.from(data['medications'] ?? [])),
        _buildListSection('Diets:', List<String>.from(data['diets'] ?? [])),
      ],
    );
  }

  Widget _buildResultSection(String title, String content, Color textColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.greenAccent),
        ),
        SizedBox(height: 10),
        Text(content, style: TextStyle(fontSize: 18, color: textColor)),
        SizedBox(height: 20),
      ],
    );
  }

  Widget _buildListSection(String title, List<String> items) {
    if (items.isEmpty) return SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.greenAccent),
        ),
        SizedBox(height: 10),
        ...items.map((item) => Text('- $item', style: TextStyle(fontSize: 16, color: Colors.white70))),
        SizedBox(height: 20),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Predict Disease'),
        backgroundColor: Colors.greenAccent,
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: Stack(
          children: [
            // Background Image
            Positioned.fill(
              child: Image.asset(
                'assets/images/background.jpg',
                fit: BoxFit.cover,
              ),
            ),
            // Semi-transparent overlay
            Positioned.fill(
              child: Container(color: Colors.black.withOpacity(0.6)),
            ),
            // Content
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildInputField(),
                    SizedBox(height: 20),
                    _buildPredictButton(),
                    SizedBox(height: 20),
                    _buildPredictionResults(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Enter Symptoms:',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        SizedBox(height: 10),
        TextField(
          controller: _symptomsController,
          decoration: InputDecoration(
            hintText: 'e.g., shivering, headache, nausea',
            hintStyle: TextStyle(color: Colors.white70),
            filled: true,
            fillColor: Colors.white.withOpacity(0.2),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8.0),
            ),
            contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
          ),
          style: TextStyle(color: Colors.white),
          maxLines: null, // Allows the TextField to grow with content
        ),
      ],
    );
  }

  Widget _buildPredictButton() {
    return Center(
      child: ElevatedButton(
        onPressed: _predictDisease,
        child: Text('Predict'),
        style: ElevatedButton.styleFrom(
          padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
          textStyle: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
