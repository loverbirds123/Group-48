package com.example.disease_prediction

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
