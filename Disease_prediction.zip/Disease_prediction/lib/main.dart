import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';  // Import Firebase core package
 // Import options file for the Firebase configuration
import 'login.dart';  // Import your login page
import 'signup.dart'; // Import your sign-up page
import 'home_page.dart';
import 'prediction_page.dart';
import 'about_page.dart';
import 'contact_page.dart';

void main() async {
  // Ensure that all Flutter bindings are initialized before initializing Firebase
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Firebase manually using FirebaseOptions
  await Firebase.initializeApp(
    options: FirebaseOptions(
      apiKey: "AIzaSyC-OvS_dQ1gKdIyl-V_2oL87-mGvLAquC0",
      authDomain: "disease-ddee0.firebaseapp.com",
      projectId: "disease-ddee0",
      storageBucket: "disease-ddee0.appspot.com",
      messagingSenderId: "965508487960",
      appId: "1:965508487960:web:efeb2234e86c3d77879c6d",
    ),
  );

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Disease Predictor',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginPage(), // Set LoginPage as the initial route
      routes: {
        '/home': (context) => HomePage(),
        '/predict': (context) => PredictionPage(),
        '/about': (context) => AboutPage(),
        '/contact': (context) => ContactPage(),
        '/signup': (context) => SignUpPage(),
        '/login': (context) => LoginPage(),// Sign-up route
      },
    );
  }
}
